-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2019 at 05:35 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `shoppcart`
--

CREATE TABLE `shoppcart` (
  `id` int(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `price` float NOT NULL,
  `discount` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppcart`
--

INSERT INTO `shoppcart` (`id`, `name`, `image`, `price`, `discount`) VALUES
(1, 'Summung galexy', 'mobile-andoried.jpg', 8950, 45),
(2, 'Nokia n serise', 'mobile-nokia.jpg', 15500, 25),
(3, 'Sonata ', 'watch-sonata.jpg', 1600, 30),
(4, 'Dell core_i3', 'laptop-php-mac.jpg', 45500, 15),
(5, 'Karizma 255CC', 'karima.jpg', 160500, 14),
(6, 'Redmi pro-9', 'redmi_pro_9.jpg', 16500, 18),
(7, 'Nokia Kepaid', 'nokia.jpg', 1850, 16),
(8, 'Apple IPhone', 'Apple_iPhone.jpg', 34600, 15);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `shoppcart`
--
ALTER TABLE `shoppcart`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `shoppcart`
--
ALTER TABLE `shoppcart`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
