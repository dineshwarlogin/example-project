<!DOCTYPE html>
<html lang="en">
<head>
  <title>E Commerce Website </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Dancing+Script" rel="stylesheet">
</head>
<body>

    <div class="jumbotron text-center">
       <h1 class="text-danger mb-5" style="font-family:'abrial fatface';"><b>ONLINE  SHOPPING CART MY BUSINESS OF SELLING PRODUCTS </b></h1>
    </div>
    <div class="container">
        <div class="row">
       
            <?php
	            $con = mysqli_connect("localhost","cotocus");
	            mysqli_select_db($con,"shopping");
	  
	       //if($conn){
	       //echo "connection is succussefully";  
	       // }
	       // else{
	       //  echo "not connected";
	       // }
	  
	            $query = "SELECT `name`, `image`, `price`, `discount` FROM `shoppcart` order by id ASC";
	            $record_query = mysqli_query($con,$query);
	            $num = mysqli_num_rows($record_query);
	            if($num >0){
		        while($product = mysqli_fetch_array($record_query)){
			?> 
			<div class="col-lg-3 col-md-3 col-sm-12">
			    <form>
			        <div class="card">
			            <h6 class="card-title bg-info text-white p-2"><b><?php echo $product['name'] ?></b></h6>
					    <div class="cord-body">
					        <img src="images/<?php echo $product['image'] ?>" alt="phone" class="img-fluid mb-2">
							<h6>&#8377;:<?php echo $product['price'] ?>&nbsp;&nbsp;(<span><?php echo $product['discount'] ?> %</span> off)</h6>
							<h6 class="badge badge-success">4.4<i class="fa fa-star"></i></h6>
							<input type="text" name="" class="form-control" placeholder="quantity">
					    </div>
						<div class="btn-group d-flex">
							  <button class="btn-success flex-fill"><b>Add to cart</button><button class="btn-warning text-white">BUy Now</b></button>
						</div>
			        </div>
			    </form>
			</div>
            <?php			
		       }
		        
               
	            }
	  
            ?>
	    </div>

	</div>
</body>
</html>