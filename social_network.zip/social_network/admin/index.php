<?php
session_start();

if(!isset($_SESSION['user_name'])){
	
	header("location: login.php");
  }
    else{
	    
   
?>
<html>
<head>
     <title>Admin Panel</title>
</head>
<body bgcolor="#1E90FF" align="center">
<a href="logout.php"><button>Logout</button></a>
<table bgcolor="gray" border="7" align="center">
      <tr><h1 bgcolor="#1E90FF"  align="center">Welcome to Admin Panel of Cotocus.com</h1>
	       <h2 align="center">Welcome<?php echo "<b style='color:white'> ".$_SESSION['user_name']."</b>";?></h2>
	      <h2 align="center" style="color:pink"><?php echo @$_GET['deleted'];?></h2>
	  </tr>
	  	
     <tr>
	        <th><font color="white">User_Id</font></th>
			<th><font color="white"> User_Name</font></th>
			<th><font color="white"> User_Password</font></th>
			<th><font color="white"> User_Email</font></th>
			<th><font color="white"> User_Country</font></th>
			<th><font color="white"> User_Gender</font></th>
			<th><font color="white"> User_Birthday</font></th>
			<th><font color="white"> User_Image</font></th>
			<th><font color="white"> User_Reg_Date</font></th>
			<th><font color="white"> User_Last_Login</font></th>
            <th><font color="white"> Status</font></th>
			<th><font color="white"> Ver_Code</font></th>
			<th><font color="white"> Posts</font></th>
			<th><font color="white"> Edit</font></th>
			<th><font color="white"> Delete</font></th>

			
   </tr>
   
  <?php 
include("../includes/connection.php");
	  $id=1;
	  //if(isset($_GET['view'])){
		  
     $select_admin = "SELECT * FROM users order by 1 DESC";

    $run = mysqli_query($con,$select_admin);
	
	while($row=mysqli_fetch_assoc($run)){
	
	   $id = $row['user_id'];
	   $user_name = $row['user_name'];
	   $user_pass = $row['user_pass'];
	   $user_email = $row['user_email'];
	   $user_country = $row['user_country'];
	   $user_gender = $row['user_gender'];
	   $user_birthday = $row['user_birthday'];
	   $user_image = $row['user_image'];
	   $user_reg_date = $row['user_reg_date'];
	   $user_last_login = $row['user_last_login'];
	   $status = $row['status'];
	   $ver_code = $row['ver_code'];
	   $posts = $row['posts'];
	  
	  
?>
   <tr>
      <td><?php echo $id; ?></td>
	  <td><?php echo  $user_name; ?></td>
	  <td><?php echo  $user_pass; ?></td>
	  <td><?php echo  $user_email; ?></td>
	  <td><?php echo  $user_country; ?></td>
	  <td><?php echo  $user_gender; ?></td>
	  <td><?php echo  $user_birthday; ?></td>
	  <td><?php echo  $user_image; ?></td>
	  <td><?php echo  $user_reg_date; ?></td>
	  <td><?php echo  $user_last_login; ?></td>
	  <td><?php echo  $status; ?></td>
	  <td><?php echo  $ver_code; ?></td>
	  <td><?php echo  $posts; ?></td>
	  <td><a href="edit.php?edit=<?php echo $id; ?>">Edit</a></td>
	  <td><a href="delete.php?del=<?php echo $id; ?>">Delete</a></td>
	  
   </tr>
	  <?php } ?>
</table>
</body>
</html>
	  <?php } ?>