<?php 
session_start();

?>
<html>
<head>
     <title>Admin Panel</title>
</head>
<body bgcolor="#1E90FF" align="center">

	<h1 bgcolor="#1E90FF" align="center">Amin can Edit Data This Form </h1>
	<?php 
	   include("../includes/connection.php");
	   
		$edit_id = @$_GET['edit'];
			
		$query = "select * from users where user_id='$edit_id'";

		$run = mysqli_query($con,$query);
		
		while($row=mysqli_fetch_array($run)){
		
		   $edit_id1 = $row['user_id'];
		   $edit_name = $row['user_name'];
		   $edit_pass = $row['user_pass'];
		   $edit_email = $row['user_email'];
		   $edit_country = $row['user_country'];
		   $edit_gender = $row['user_gender'];
		   $edit_birthday = $row['user_birthday'];
		   $edit_image = $row['user_image'];
		   $edit_reg_date = $row['user_reg_date'];
		   $edit_last_login = $row['user_last_login'];
		   $edit_status = $row['status'];
		   $edit_ver_code = $row['ver_code'];
		   $edit_posts = $row['posts'];    
	?>

	
	<form method="post" action="edit.php?edit_form=<?php echo  $edit_id1; ?>" enctype="multipart/form_data">
		<table border="3" bgcolor="gray" style="color:white;" align="center">
			<tr>
			  <td><b>user_name</b></td><td><input type="text" name="user_name" value="<?php echo $edit_name; ?>"/></td>
			</tr>
			<tr>
			  <td><b>user_pass</b></td><td><input type="password" name="user_pass" value="<?php echo $edit_pass; ?>/"></td>
			</tr>
			<tr>
			  <td><b>user_email</b></td><td><input type="email" name="user_email" value="<?php echo $edit_email; ?>"/></td>
			</tr>
			<tr>
			   <td><b>user_coutry</b></td><td><input type="text" name="user_country" value="<?php echo $edit_country; ?>"/></td>
			</tr>					
			<tr>
			  <td><b>user_gender</b></td><td><input type="text" name="user_gender" value="<?php echo $edit_gender; ?>"/></td>
			</tr>
			<tr>
			  <td><b>user_birthday</b></td><td><input type="date" name="user_birthday" value="<?php echo $edit_birthday; ?>"/></td>
			</tr>
			<tr>
			   <td><b>user_image</b></td><td><input type="text" name="user_image" value="<?php echo $edit_image; ?>"/></td>
			</tr>
			<tr> 
			  <td><b>user_reg_date</b></td><td><input type="date" name="user_reg_date" value="<?php echo $edit_reg_date; ?>"/></td>
			</tr>
			<tr> 
			   <td><b>user_last_login</b></td><td><input type="date" name="user_last_login" value="<?php echo $edit_last_login; ?>"/></td>
			</tr>
			<tr>
			  <td><b>status</b></td><td><input type="text" name="status" value="<?php echo $edit_status; ?>"/></td>
			</tr>
			<tr>
				<td><b>ver_code</b></td><td><input type="verified" name="ver_code" value="<?php echo $edit_ver_code; ?>"/></td>
			</tr>
		  <tr> 
			  <td><b>posts</b></td><td><input type="text" name="posts" value="<?php echo $edit_posts; ?>"/></td>
		  </tr>
		  <tr> 
			  <td> <input type="submit" name="update" value="Update"/></td>
		 </tr>
	
		 <?php } ?>
	    </table>
    </form>
</body>
</html>
<?php 

    if(isset($_POST['update'])){
	
	   $update_id = $_GET['edit_form'];
	   
	   $update_name = $_POST['user_name'];
	   $update_pass = $_POST['user_pass'];
	   $update_email = $_POST['user_email'];
	   $update_country =$_POST['user_country'];
	   $update_gender = $_POST['user_gender'];
	   $update_birthday = date('y-m-d');
	   $update_image = $_FILES['user_image']['name'];
	   $update_image_type = $_FILES['user_image']['type'];
	   $update_image_size = $_FILES['user_image']['size'];
	   $update_image_tmp = $_FILES['user_image']['tmp_name'];
	   
	   move_uploaded_file($update_image_tmp,"../images/$update_image");
	   
	   $update_reg_date = date('y-m-d');
	   $update_last_login = date('y-m-d');
	   $update_status = $_POST['status'];
	   $update_ver_code = $_POST['ver_code'];
	   $update_posts = $_POST['posts'];
	   
	   
	   $update_query = "update  users set user_name='$update_name',user_pass='$update_pass',user_email='$update_email',user_country='$update_country',user_gender='$update_gender',user_birthday='$update_birthday',user_image='$update_image', user_reg_date='$update_reg_date',user_last_login='$update_last_login',status='$update_status',ver_code='$update_ver_code',posts='$update_posts' where user_id='$update_id'";
	   
	   if(mysqli_query($con,$update_query)){
		   echo "<script>window.open('index.php?updated=post has bee updated','_self')</script>";
	   
	   }
    
	}
	 
?>
 