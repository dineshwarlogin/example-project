<?php 
session_start();

?>

<html>
<body bgcolor="#1E90FF">
<form method="post" action="login.php">
       
    <table border="15" width="600" bgcolor="red" style="color:white;" colspan="5" align="center">
	    <tr><td colspan="5"><h1 align="center">Admin login</h1></td></tr>
        <tr>
	      <td align="right"><b>User Name</b></td><td><input type="text" name="user_name" placeholder="email@gail.com" required="required" width="60" /></td>
		</tr>
	    <tr>
	      <td align="right"><b>User Password</b></td><td><input type="password" name="user_password" width="60" placeholder="******" required="required" /></td>
		</tr>				
	    <tr>
	      <td></td><td align="left"> <input type="submit" width="15" name="login" value="Login"/></td>
	    </tr>

    </table>
</form>
</body>
</html>
<?php 
include("../includes/connection.php");
if(isset($_POST['login'])){
	  
	$user_name = mysqli_real_escape_string($con,$_POST['user_name']);
	$user_pass = mysqli_real_escape_string($con,$_POST['user_password']);
	
	$login_query = "select * from admin_login where user_name='$user_name' AND user_password='$user_pass'";
	
	$run = mysqli_query($con,$login_query);
	
	if(mysqli_num_rows($run)>0){
		
		$_SESSION['user_name']=$user_name;
		
	     echo "<script>window.open('index.php','_self')</script>";
	
        }
	else{
		  echo "<script>alert('User Name or Password is incorrect!')</script>";
	   }
   }
   
?>
