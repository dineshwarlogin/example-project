<?php 
include("../includes/connection.php");
	  $delete_id = $_GET['del'];
	  
     $delete_admin = "delete  FROM users  where user_id='$delete_id'";

    if(mysqli_query($con,$delete_admin)){
		echo "<script>window.open('index.php?deleted= A post has been deleted','_self')</script>";
	}
	   
?>