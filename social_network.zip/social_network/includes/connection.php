<?php 


//$con = mysqli_connect("localhost","root","","social_network");  OR

$db_servername = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "social_network";

// Create connection
$con = mysqli_connect($db_servername,$db_username, $db_password, $db_name);


?>