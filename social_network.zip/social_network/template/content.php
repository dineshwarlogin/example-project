        <div id="content"><!--- content area start here------>
		    <div><!-- banner start here--->
			   <h2 id="h2">Join the Largest Educational Network</h2>
				<img src="images/banner.jpg" alt="baner"/>
		    </div><!-- banner end here---><br/>
			<div><!---form2 start here--->
			    <form id="form2" action="" method="post"><h2>Sign up Today!</h2>
				 <table>
				    <tr>
						<td align="right"><strong>Name:</strong></td>
						<td><input type="text" name="u_name" placeholder="write your name" required="required"/></td>
					</tr>
					<tr>
						<td align="right"><strong>Password:</strong></td>
						<td><input type="password" name="u_pass" placeholder="enter a password" required="required"/></td>
					</tr>
					<tr>
						<td align="right"><strong>Email:</strong></td>
						<td><input type="email" name="u_email" placeholder="write your mail" required="required"/></td>
					</tr>
					<tr>
						<td align="right"><strong>Country:</strong></td>
						<td><input type="text" name="u_country" placeholder="write your country" required="required"/></td>
					</tr>
					<tr>
						<td align="right"><strong>Gender:</strong></td>
						<td>
						    <select name="u_gender">
								<option>Male</option>
								<option>FeMale</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align="right"><strong>Birthday:</strong></td>
						<td><input type="date" name="u_birthday" required="required"/></td>
					</tr>
					<tr><td></td>
						<td align="right"><button name="sign_up"><b>Sign up!</b></button></td>
					</tr>
				 </table>
			   </form>
			   <?php include("insert_user.php");?>
			</div><!----form2 end here--->
		</div><!--- content area  end here------>