        <div id="footer"><!---footer start here-->
			  <h2>Design by&copy;dineshwar.cotocu@gmail.com</h2>
		</div><!---footer end here-->
	</div>
	<!--container end here---->    
</body>
</html>