<!DOCTYPE html>
<html>
<head>
<title>Social Network!</title>
<link type="text/css" rel="stylesheet" href="styles/style.css" media="all"/>
</head>
<body>
    <!--container start here---->
    <div class="container">
	    <!--- header-wrapper start heare--->
	    <div id="header_wrapper">
	       <!-- header start here--->   
		   <div id="header">
		     <img src="images/banner.png" height="100px" style="float:left;"/> 
			 <form action="" method="post" id="form1">
			    <strong>Email:</strong>
				<input type="email" name="email" placeholder="Email" required="required"/>
				<strong>Password:</strong>
				<input type="password" name="pass" placeholder="******" required="required"/>
				<button name="login">Login</button>
			 </form>
		   </div>
		   <!-- header end here--->  
	   </div>
	   <!--- header-wrapper end heare--->