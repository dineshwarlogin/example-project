-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2018 at 06:37 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`user_id`, `user_name`, `user_password`) VALUES
(1, 'dineshwar@gmail.com', 'din15390'),
(2, 'Dineshwar paswan', 'din15390');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_country` text NOT NULL,
  `user_gender` text NOT NULL,
  `user_birthday` text NOT NULL,
  `user_image` text NOT NULL,
  `user_reg_date` text NOT NULL,
  `user_last_login` text NOT NULL,
  `status` text NOT NULL,
  `ver_code` int(100) NOT NULL,
  `posts` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_pass`, `user_email`, `user_country`, `user_gender`, `user_birthday`, `user_image`, `user_reg_date`, `user_last_login`, `status`, `ver_code`, `posts`) VALUES
(18, 'bimla', 'mnb123', 'bima@gmail.com', 'austerilya', 'female', '2017-07-18', '', '17-12-14', '17-12-14', 'verified', 770684538, 'no'),
(17, 'Ram', '123mnba', 'ram@gmail.com', 'pakishtan', 'male', '2017-12-12', '', '17-12-14', '17-12-14', 'verified', 1645008372, 'no'),
(43, 'Divya kumari', 'divya123', 'divya@gmail.com', 'Pakishtan', 'FeMale', '2000-01-01', 'default.jpg', '2018-01-10 15:36:21', '', 'verified', 186886612, 'no'),
(15, 'kara', 'karan123', 'karat@gmail.com', 'bharat', 'Male', '2017-12-10', 'default.jpg', '2017-12-13 14:00:08', '', 'verified', 1488140004, 'no'),
(19, 'sony', 'sony0987', 'sony@gmail.com', 'bangladesh', 'male', '2017-05-17', '', '17-12-14', '17-12-14', 'verified', 1102033207, 'mane app ka messege recive kaliya ha'),
(20, 'rohit kumar', 'rohi1123', 'rohit@gmail.com', 'egland', 'male', '2017-10-18', '', '17-12-14', '17-12-14', 'verified', 751333459, 'please check job for apply'),
(21, 'agcjnv', 'nCBDJV', 'ALOK.AARAH@GMAIL.COM', 'India', 'female', '2017-12-03', '', '17-12-14', '17-12-14', 'verified', 178950781, 'i have join'),
(41, 'Ajay kumar', 'ajay123', 'ajay@gmail.com', 'Amrica', 'Male', '1996-02-05', 'default.jpg', '2018-01-10 14:43:50', '', 'verified', 1941708488, 'no'),
(23, 'dineshwar', 'dineshwar', 'dineshwar@example', 'zsdfghhb ', 'male', '2017-09-05', '', '17-12-14', '17-12-14', 'verified', 868450552, 'i needjob '),
(42, 'Archana kumari', 'archna', 'archana@gmail.com', 'indian', 'FeMale', '1998-03-20', 'default.jpg', '2018-01-10 15:29:46', '', 'verified', 287403370, 'no'),
(38, 'muny kumari', 'mine12', 'muny@gmail.com', 'newsland', 'famele', '2017-12-31', '', '18-01-04', '18-01-04', 'verified', 1801276960, 'somthing'),
(39, 'karan', 'karana', 'karan@gmail.com', 'soudiarb', 'Male', '1980-07-14', 'default.jpg', '2018-01-10 14:38:12', '', 'verified', 876003320, 'no'),
(40, 'Mnish Agrawal', 'mnisha', 'mnish@gmail.com', 'Soudiarb', 'Male', '1992-02-04', 'default.jpg', '2018-01-10 14:41:41', '', 'verified', 2057757001, 'no'),
(28, 'mhabir', 'mnb1234', 'mhabir@gmail.com', 'bhutan', 'male', '2017-12-04', '', '17-12-14', '17-12-14', 'verified', 1773208463, 'i have join'),
(29, 'sriwat', 'sriwastaw', 'sriswa@gmail.com', 'India', 'male', '2017-12-18', '', '17-12-14', '17-12-14', 'verified', 1744271330, 'please give me job'),
(35, ' kumar paswan', 'kumarpas', 'kumar@gmail.com', 'India', 'female', '18-01-04', '', '18-01-04', '18-01-04', 'verified', 1613971809, 'I need  job of engeneer'),
(36, 'DINESHWAR PASWAN', 'peooru', 'DINESH@GMAIL.COM', 'India', 'Male', '2017-12-04', 'default.jpg', '2017-12-19 20:44:59', '', 'verified', 1041027061, 'no'),
(37, 'radika', 'radika/', 'radhika@gmail.com', 'India', 'FeMale', '18-01-03', '', '18-01-03', '18-01-03', 'verified', 808154098, 'no'),
(34, 'pinki kumari', 'pinki123/', 'pink@gmail.com', 'nepal', 'FeMale', '18-01-03', '', '18-01-03', '18-01-03', 'verified', 460518873, 'Any one');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
