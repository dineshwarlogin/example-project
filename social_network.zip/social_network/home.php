<?php
session_start();
     if(empty($_SESSION['user_email'])){
	header("location: index.php");
}
?>
    
<html>
<head>
     <title>Home page</title>
	 <style type="text/css">
	  .nav{ padding:o; margin-left:50px; background:green; width:1200px; height:150px; float:left; align:center;}
	   ul li{list-style:none; display:inline; float:left; color:white; padding:30px; font-size:30px;}
	    li a:link{text-decoration:none; color:yellow;}
	    a:link:hover{text-decoration:underline; color:red;}
	 </style>
</head>
<body bgcolor="#1E90FF">
<font color="white" size="30"><h3 align="center"> Welcome to the Social network!</h3></font>
 <div class="nav"> 
		<ul>
		  <li><a href="#">Home</a></li>
		  <li><a href="#">About us</a></li>
		  <li><a href="#">Service</a></li>
		  <li><a href="#">Contact us</a></li>
		  <li><a href="#">Project</a></li>
		  <li><a href="logout.php">logout</a></li>
		</ul>
 </div>

</body>
</html>
