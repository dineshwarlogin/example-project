<html>
<body bgcolor="pink">
<form method="post" action="user.php" enctype="multipart/form_data">
    <table border="3" bgcolor="#1E90FF" align="center"><h1 align="center">User Register here</h2>
        <tr>
	      <td><b>user_name</b></td><td><input type="text" name="user_name" required/></td>
		</tr>
	    <tr>
	      <td><b>user_pass</b></td><td><input type="password" name="user_pass" required/></td>
		</tr>
	    <tr>
	      <td><b>user_email</b></td><td><input type="email" name="user_email" requrired/></td>
		</tr>
	    <tr>
	       <td><b>user_coutry</b></td><td><input type="text" name="user_country" required/></td>
		</tr>
	    <tr>
	      <td><b>user_gender</b></td><td><input type="text" name="user_gender" required/></td>
		</tr>
	    <tr>
	      <td><b>user_birthday</b></td><td><input type="date" name="user_birthday" required/></td>
		</tr>
	    <tr>
	       <td><b>Select a file</b></td>
		   	<td><input type="file" name="user_image" required/></td>
	    </tr>
	    <tr> 
	      <td><b>user_reg_date</b></td><td><input type="date" name="user_reg_date" required/></td>
	    </tr>
	    <tr> 
	         <td><b>user_last_login</b></td><td><input type="date" name="user_last_login" required/></td>
	    </tr>
	    <tr>
	      <td><b>status</b></td><td><input type="text" name="status" required/></td>
		</tr>
	    <tr>
		    <td><b>ver_code</b></td><td><input type="verified" name="ver_code" required/></td>
		</tr>
	  <tr> 
	      <td><b>posts</b></td><td><input type="text" name="posts" required/></td>
	  </tr>
      <tr> 
	      <td> <input type="submit" name="submit" value="Submit"/></td>
	 </tr>

	</table>
</form>
</body>
</html>
<?php 
include("../includes/connection.php");
if(isset($_POST['submit'])){

    $name = $_POST['user_name'];
	$pass = $_POST['user_pass'];
	$email = $_POST['user_email'];
	$country = $_POST['user_country'];
	$gender = $_POST['user_gender'];
	$birthday = $_POST['user_birthday'];
	$user_image = $_FILES['user_image']['name'];
	$user_image_type = $_FILES['user_image']['type'];
	$user_image_size = ($_FILES['user_image']['size']/1024)."kb";
	$user_image_tmp =  $_FILES['user_image']['tmp_name'];
	move_uploaded_file($_user_image_tmp,"images/$user_image");
	     
	
	
	$user_reg_date = date('y-m-d');
	$user_last_login = date('y-m-d');
	$status = "verified";
	$ver_code = mt_rand();
	$posts = $_POST['posts'];
	
		
		if(strlen($pass)<6){
			echo "<script>alert('Please minimum pass shoude be 6 characters')</script>";
			exit();
		}
		
		$check_email = "select * from users where user_email='$email'";
		
		$run_email = mysqli_query($con,$check_email);
		
		$check = mysqli_num_rows($run_email);
		
		if($check==1) {
			echo"<script>alert('Email already exist, please tri another email')</script>";
			
			exit();
		}
		
        $insert = "insert into users (user_name, user_pass, user_email, user_country, user_gender, user_birthday, user_image,user_reg_date, user_last_login, status, ver_code, posts)
		values ('$name','$pass','$email','$country','$gender','$birthday','$user_image','$user_reg_date','$user_last_login','$status','$ver_code','$posts')";		
		  
		$query = mysqli_query($con,$insert);
		
		if($query){
			echo "<h3 style='width:900px; text-align:justify; color:green;'>Hi, <b>$name</b> congratulations, Submission has succesfully , please check your email for final verification.</h3>";
		}
		else{
			echo "<h3 style='width:400px; text-align:justify; color:green;'>Submission has failed try again!</h3>";
		}
  
    }
?>