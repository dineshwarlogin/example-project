<?php 
include("includes/database.php");
?>
<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title> My Shoop</title>
		<link rel="stylesheet" type="text/css" href="css/stylesheet.css" media="all" />
		<!--- <script type="text/javascript" src="javascrip/"></script>/------>
	</head>
	<body>
	   <!----main container start--->
	    <div class="container _wrapper">
		
			<div class="header _wrapper"><!----header banner start section --->
				 <a href="#"> <img src="images/logo-of-ecommerce.png" style="float:left; margin-left:173px;" /></a>
				  <img src="images/banner.jpg" style="float:right; margin-right:176px;" />
			</div><!----header banner end section /--->
		   <!----navbar section start--->
			<div id="navbar">
				  <ul id="manu"><!-------manu start---->
				    <?php
						
						$get_nav = "SELECT * FROM navbar";
						
						$run_nav = mysqli_query($con, $get_nav);
						
						while($row_nav=mysqli_fetch_array($run_nav)){
						

						      $home = $row_nav['home'];
							  $about_us  = $row_nav['about_us'];
							  $services = $row_nav['services'];
							  $all_products = $row_nav['all_products'];
							  $contact_us = $row_nav['contact_us'];
							  						
						    echo "<li><a href='index.php?nav=home'>$home</a></li>";
						    echo "<li><a href='index.php?nav=about us'>$about_us</a></li>";
						    echo "<li><a href='index.php?nav=services'>$services</a></li>";
						    echo "<li><a href='index.php?nav=All products'>$all_products</a></li>";
						    echo "<li><a href='contact.php?nav=contact us'>$contact_us</a></li>"; 
	
						   /*
						   <li><a href="#">Home</a></li>";
						   <li><a href="#">About Us</a></li>
						   <li><a href="#">Services</a></li>
						   <li><a href="#">All Products</a></li>
						   <li><a href="#">Contact Us</a></li>
						   */
						}
					?>
				  </ul><!----manu end/---->
				  <div id="seach">
				     <form method="get" action="result.php" enctype="multipart/form-data">
					 <input type="search" name="search" placeholder="Seach Any Product Here......">
					 <button type="submit" name="submit">Search</button>
					 </form>
				  </div>
			</div>
		    <!----navbar section end --->
		    <!----side_bar section --->
			<div class="content_wrapper">
			    <!----left_sidebar section start--->
				<div id="left_sidebar">
					     <h1>Electronic Device's</h1>
						  <ul>
						        <?php
								
									$get_categ = "Select * From electronics_device";
									
									$run_categ = mysqli_query($con, $get_categ);
									
									while($row_categ=mysqli_fetch_array($run_categ)){
									   
										$categ_id=$row_categ["device_id"];
										
										$categ_title=$row_categ["device_title"];
										
										 echo "<li><a href='index.php?device=$categ_id'>$categ_title</a></li>";
									}
								?>
						  </ul>
						  
						  <h1>Electronic Brand's</h1>
						  <ul>
						    <?php
								
									$get_brand = "Select * From brands";
									
									$run_brand = mysqli_query($con, $get_brand);
									
									while($row_brand=mysqli_fetch_array($run_brand)){
									   
										$brand_id=$row_brand["brand_id"];
										
										$brand_title=$row_brand["brand_title"];
										
										 echo "<li><a href='index.php?brand=$brand_id'>$brand_title</a></li>";
									}
								?>
						  
						  </ul>
						  <h1>Man Fashion's</h1>
						  <ul>
						      <li><a href="#">Casual shirt's</a></li>
							  <li><a href="#">Casual jeans's</a></li>
								<li><a href="#">Casual sweater's</a></li>
							  <li><a href="#">Formal dress's</a></li>
							  <li><a href="#">Casual blazer's</a></li>
							
						  </ul>
				</div>
				<!----left_sidebar section end/--->
				<!----right_content section start--->
				<div id="right_content">
					     <h3>Right content area</h3>
						  <p>Right content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content    </p>
						  <h3>Right content area</h3>
						  <p>Right content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content    </p><h3>Right content area</h3>
						  <p>Right content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content    </p>
						  <h3>Right content area</h3>
						  <p>Right content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content areaRight content    </p><h3>Right content area</h3>
						  

			    </div> 
				<!----right_content section end--->
			</div>
		    <!----side_bar section end--->
		
			<div id="footer"><!----footer section start--->
			        <p>Design By :<b> Dineshwar paswan</b></p>
			</div><!----footer section end--->
	    </div>
	  <!----main container end--->
	</body>
</html>