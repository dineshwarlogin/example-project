-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 16, 2018 at 03:45 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Sammsung'),
(2, 'Nokia'),
(3, 'LG'),
(4, 'Intex'),
(5, 'Philips'),
(6, 'PHP'),
(7, 'Dell'),
(8, 'Oriental'),
(9, 'Proxy'),
(10, 'Bajaj'),
(11, 'Sony'),
(12, 'Sonata'),
(13, 'Titan');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(11) NOT NULL,
  `ip_add` int(11) NOT NULL,
  `quntity` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `electronics_device`
--

CREATE TABLE `electronics_device` (
  `device_id` int(11) NOT NULL,
  `device_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electronics_device`
--

INSERT INTO `electronics_device` (`device_id`, `device_title`) VALUES
(1, 'Laptops'),
(2, 'Computers'),
(3, 'Mobiles'),
(4, 'LAD TVs'),
(5, 'Refrigerators'),
(6, 'Fans'),
(7, 'Tablets'),
(8, 'Powerbanks'),
(9, 'Colers'),
(10, 'Radios'),
(11, 'Digitals Camra'),
(12, 'Washing Machines');

-- --------------------------------------------------------

--
-- Table structure for table `navbar`
--

CREATE TABLE `navbar` (
  `id` int(5) NOT NULL,
  `home` text NOT NULL,
  `about_us` text NOT NULL,
  `services` text NOT NULL,
  `all_products` text NOT NULL,
  `contact_us` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `navbar`
--

INSERT INTO `navbar` (`id`, `home`, `about_us`, `services`, `all_products`, `contact_us`) VALUES
(1, 'Home', 'About us', 'Services', 'All Products', 'Contact us');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `device_id` int(10) NOT NULL,
  `brand_id` int(10) NOT NULL,
  `date` timestamp NOT NULL,
  `product_title` varchar(100) CHARACTER SET utf8 NOT NULL,
  `product_img1` text CHARACTER SET utf8 NOT NULL,
  `product_img2` text CHARACTER SET utf8 NOT NULL,
  `product_img3` text CHARACTER SET utf8 NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` varchar(100) CHARACTER SET utf8 NOT NULL,
  `status` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `electronics_device`
--
ALTER TABLE `electronics_device`
  ADD PRIMARY KEY (`device_id`);

--
-- Indexes for table `navbar`
--
ALTER TABLE `navbar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `electronics_device`
--
ALTER TABLE `electronics_device`
  MODIFY `device_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
