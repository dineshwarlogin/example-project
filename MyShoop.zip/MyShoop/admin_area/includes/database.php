<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myshop";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

?>