<?php 

include("includes/database.php");

?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
		<title>Insert MyShop</title>
	</head>
	<body bgcolor="gray">
			<form action="insert_product.php" method="POST" enctype="multipart/form-data">
		   
				<table width="750" border="5" align="center" style="background:teal; color:white;">
					<tr bgcolor="Teal">
					   <td colspan="2"  align="center"><h1>Insert Product</h1></td>
					</tr>
					<tr>
						<td align="right"><b>Product Title:</b></td>
						<td><input type="text" name="product_title" size="50" placeholder="Enter title name.here"/></td>
					</tr>
					<tr>
						<td align="right"><b>Product Devices:</b></td>
						<td>
						    <select name="product_device">
							     <option>Select a Device</option>
								 <?php
								
									$get_categ = "Select * From electronics_device";
									
									$run_categ = mysqli_query($con, $get_categ);
									
									while($row_categ=mysqli_fetch_array($run_categ)){
									   
										      $categ_id=$row_categ["device_id"];
										
										      $categ_title=$row_categ["device_title"];
										
										 echo "<option value=$categ_id'>$categ_title</option>";
									}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td align="right"><b>Product Brands:</b></td>
						<td>
						    <select  name="product_brand">
							     <option>Select a Brand</option>
								 <?php
								
									$get_brand = "Select * From brands";
									
									$run_brand = mysqli_query($con, $get_brand);
									
									while($row_brand=mysqli_fetch_array($run_brand)){
									   
										         $brand_id=$row_brand["brand_id"];
										
										        $brand_title=$row_brand["brand_title"];
										
										 echo "<option value='$brand_id'>$brand_title</option>";
									}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<td align="right"><b>Product Image1:</b></td>
						<td><input type="file" name="product_img1" /></td>
					</tr>
					<tr>
						<td align="right"><b>Product Image2:</b></td>
						<td><input type="file" name="product_img2" /></td>
					</tr>
					<tr>
						<td align="right"><b>Product Image3:</b></td>
						<td><input type="file" name="product_img3"/></td>
					</tr>
					<tr>
						<td align="right"><b>Product Price:</b></td>
						<td><input type="text" name="product_price" placeholder=" Rs 15000.00"/></td>
					</tr>
					<tr>
						<td align="right"><b>Product Description:</b></td>
						<td>
						<textarea type="text" name="product_desc" cols="60" rows="10" placeholder="Please admin write here -----------something about product"></textarea>
						</td>
					</tr>
					<tr>
						<td align="right"><b>Product Keywords:</b></td>
						<td><input type="text" name="product_keywords" size="50" placeholder="Enter keywords here"/></td>
					</tr>
					<tr>
						<td colspan="2" align="center"><input type="submit" name="insert" value="Insert Product"/></td>
					</tr>
				</table>
			</form>
	</body>
</html>
<?php

    if(isset($_POST['insert'])){
		
			
			$product_title = $_POST['product_title'];
			$product_device = $_POST['product_device'];
			$product_brand = $_POST['product_brand'];
			$product_price = $_POST['product_price'];
			$product_desc = $_POST['product_desc'];
			$status = 'on';
			$date = date('d/m/y');
			$product_keywords = $_POST['product_keywords'];
			
			//Image  names
			$product_img1 = $_FILES['product_img1']['name'];
			$product_img2 = $_FILES['product_img2']['name'];
			$product_img3 = $_FILES['product_img3']['name'];
			
			//Image  temp names
			$temp_name1 = $_FILES['product_img1']['tmp_name'];
			$temp_name2 = $_FILES['product_img2']['tmp_name'];
			$temp_name3 = $_FILES['product_img3']['tmp_name'];
			
				if($product_title=='' OR $product_device=='' OR $product_brand=='' OR $product_price=='' OR $product_desc==''  OR $product_keywords=='' OR $product_img1=='' OR $product_img2=='' OR $product_img3==''){
					
						   echo "<script>alert('Please fill all the  field!')</script>";
						   exit();
					
				}
	
				else{
					
					//uploading images to its folder
					
					move_uploaded_file($temp_name1,"products_images/$product_img1");
					move_uploaded_file($temp_name2,"products_images/$product_img2");
					move_uploaded_file($temp_name3,"products_images/$product_img3");

					$insert_prodects = "INSERT INTO products (device_id, brand_id, date, product_title, product_img1, product_img2, product_img3, product_price, product_desc, status) VALUES ('$product_device','$product_brand','$date','$product_title','$product_img1','$product_img2','$product_img3','$product_price','$product_desc','$status')";
					
					$run_products = mysqli_query($con,$insert_prodects);
			
						if($run_products){
							
							echo"<script>alert('Product has been successfully!')</script>";
							
						}
						else{
							
							echo"<script>alert('Product dose not successfully!')</script>";
						}
			           
				}
    }

?>













